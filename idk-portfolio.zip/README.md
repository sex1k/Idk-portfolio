# Idk Portfolio

A free, responsive portfolio made with plain HTML, CSS and JavaScript.

## Edit
Open `index.html` and replace:
- Project One / Two / Three
- About text
- `hello@example.com`

You can also replace the CSS-generated project visuals with your own images later.

## Publish for free
1. Create a GitHub account at https://github.com
2. Create a new repository named `idk-portfolio` (or `YOURUSERNAME.github.io` if you want the shortest URL).
3. Upload `index.html`, `style.css`, `script.js` and the `images` folder.
4. Repository → Settings → Pages.
5. Under Build and deployment choose `Deploy from a branch`.
6. Select `main` and `/ (root)`, then Save.
7. Wait a minute or two. GitHub will show the public site URL.

If your repository is `YOURUSERNAME.github.io`, the address will be:
https://YOURUSERNAME.github.io/
Otherwise it will normally be:
https://YOURUSERNAME.github.io/idk-portfolio/

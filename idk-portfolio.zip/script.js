const cursor=document.querySelector('.cursor');
const ring=document.querySelector('.cursor-ring');
let mx=0,my=0,rx=0,ry=0;
window.addEventListener('mousemove',e=>{
  mx=e.clientX; my=e.clientY;
  cursor.style.left=mx+'px'; cursor.style.top=my+'px';
});
function follow(){
  rx += (mx-rx)*.14; ry += (my-ry)*.14;
  ring.style.left=rx+'px'; ring.style.top=ry+'px';
  requestAnimationFrame(follow);
}
follow();

document.querySelectorAll('a,button,.skills span').forEach(el=>{
  el.addEventListener('mouseenter',()=>{ring.style.width='60px';ring.style.height='60px'});
  el.addEventListener('mouseleave',()=>{ring.style.width='34px';ring.style.height='34px'});
});

const projects=document.querySelectorAll('.project');
projects.forEach(p=>{
  p.addEventListener('mousemove',e=>{
    const r=p.getBoundingClientRect();
    const x=(e.clientX-r.left)/r.width-.5;
    const y=(e.clientY-r.top)/r.height-.5;
    p.querySelector('.project-image').style.transform=`perspective(900px) rotateY(${x*5}deg) rotateX(${-y*5}deg) scale(1.01)`;
  });
  p.addEventListener('mouseleave',()=>{
    p.querySelector('.project-image').style.transform='';
  });
});

// Reveal sections as they enter the screen
const observer=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){
      entry.target.animate(
        [{opacity:0,transform:'translateY(35px)'},{opacity:1,transform:'translateY(0)'}],
        {duration:800,easing:'cubic-bezier(.2,.8,.2,1)',fill:'forwards'}
      );
      observer.unobserve(entry.target);
    }
  });
},{threshold:.12});
document.querySelectorAll('.section-label,.about-content,.skills,.contact-content').forEach(el=>observer.observe(el));
